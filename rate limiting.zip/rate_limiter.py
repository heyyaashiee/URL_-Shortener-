"""
Rate limiting (Step 6 of the roadmap).

A simple in-memory sliding-window limiter: for each key (here, user id),
we keep a list of timestamps of their recent requests. If they've made
`max_requests` or more within the last `window_seconds`, we reject with
HTTP 429.

⚠️ Limitation: this state lives in a Python dict in this process's memory.
It works fine for a single-process dev server or a small deployment, but
it resets on restart and does NOT share state across multiple server
instances. A production deployment running multiple workers/replicas
would need a shared store (e.g. Redis) instead -- see the optional
"Caching Layer" step in the roadmap, which adds Redis and could hold
rate-limit counters too.
"""

import time
from collections import defaultdict
from fastapi import Depends, HTTPException, status

from app.auth import get_current_user
from app import models


class RateLimiter:
    def __init__(self, max_requests: int, window_seconds: int):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        # key -> list of request timestamps (seconds since epoch)
        self._request_log: dict[int, list[float]] = defaultdict(list)

    def __call__(self, current_user: models.User = Depends(get_current_user)) -> models.User:
        now = time.time()
        window_start = now - self.window_seconds

        timestamps = self._request_log[current_user.id]

        # Drop timestamps that have fallen outside the window
        while timestamps and timestamps[0] < window_start:
            timestamps.pop(0)

        if len(timestamps) >= self.max_requests:
            retry_after = int(self.window_seconds - (now - timestamps[0]))
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=(
                    f"Rate limit exceeded: max {self.max_requests} requests "
                    f"per {self.window_seconds} seconds."
                ),
                headers={"Retry-After": str(max(retry_after, 1))},
            )

        timestamps.append(now)
        # Returning the user lets this dependency double as an auth check
        # too, but routes that already depend on get_current_user separately
        # are unaffected -- FastAPI resolves shared dependencies once per request.
        return current_user
